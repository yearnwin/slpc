<template>
  <div class="solution">
    <section>
      <img src="../../static/img/10.png" class="page-img" alt="">
      <div class="page-solu-top">
        <ul class="page-solu-nav">
          <li v-for="item in list" v-bind:key="item.id" @click="mycs(item.id)">{{item.name}}</li>
        </ul>
      </div>
      <div class="page-solution">
        <div class="page-solu-con">
            <solutionson :listid='listid'></solutionson>
        </div>
        <div class="customer">
          <div class="news-tit">
            <div class="news-tit-con">
              <span>我们的客户</span>
              <span>OUR CUSTOMERS</span>
            </div>
            <div class="news-subhead">全心全力服务好我们的每一个客户，选择惠恩，享受高品质服务。</div>
          </div>
          <div class="customer-con">
            <ul>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
<script>
import solutionson from './SolutionSon/SolutionSon'
export default {
    name:'Solution',
    data() {
        return {
            listid:0,
            list:[
                {id:0,name:'人力资源外包'},
                {id:1,name:'业务外包'},
                {id:2,name:'猎头人才'},
                {id:3,name:'企业管理'},
                {id:4,name:'社保及公积金'},
                {id:5,name:'财务外包'},
                {id:6,name:'保安保洁外包'},
                {id:7,name:'居住证及落户'},
                {id:8,name:'外包案例'},
                {id:9,name:'HRD商学院'},
            ]
        }
    },
    methods: {
        mycs(id) {
            this.listid=id
            console.log(id)
        },
    },
    components:{
        solutionson,
    }
}
</script>
