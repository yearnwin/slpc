<template>
  <div class="footer">
    <footer>
      <img src="../../static/img/footer.png" alt="" class="footer-img">
      <div class="footer-area">
        <div class="footer-con">
          <div class="footer-left">
            <img src="../../static/img/logo.png" alt="" class="footer-logo">
            <a href="" class="footer-order">在线预约</a>
          </div>
          <div class="footer-mid">
            <ul>
              <li><span>联系我们</span>/CONTACT US</li>
              <li>联系电话 4000-000-000</li>
              <li>企业邮箱 XX@163.COM</li>
              <li>公司地址 于上海大虹桥板块商务园区漓江桥万达广场</li>
            </ul>
          </div>
          <div class="footer-right">
            <div class="footer-ewm">
              <img src="../../static/img/erweima.png" alt="">
              <span>关注微信公众号</span>
            </div>
            <div class="footer-ewm">
              <img src="../../static/img/erweima.png" alt="">
              <span>关注微信订阅号</span>
            </div>
          </div>
        </div>
      </div>
      <div class="record-msg">
        COPYRIGHT @ 2009-2011,WWW.XXXXXX.COM,ALL RIGHTS RESERVED 沪ICP备XXXXXX号
      </div>
    </footer>
  </div>
</template>
<script>
export default {
    name:'myfooter',
    data() {
        return {
            
        }
    },
}
</script>