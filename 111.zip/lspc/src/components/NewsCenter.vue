<template>
  <div class="newscenter">
    <section>
      <img src="../../static/img/12.png" alt="" class="page-img">
      <div class="news-page page">
        <div class="news-module" @click="godetails()">
            <div class="page-news-img">
              <img src="../../static/img/13.png" alt="">
            </div>
            <div class="news-hanzi">
              <div class="news-title">企业校园营销如何让用户更快下单？</div>
              <div class="news-content">
                完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的培训，为企业避免因地推人员流完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的
              </div>
              <div class="news-message">
                <span class="news-liulan">浏览量：125</span>
                <span class="news-date">时间：2019-2-26</span>
              </div>
            </div>
        </div>
        <div class="news-module" @click="godetails()">
            <div class="page-news-img">
              <img src="../../static/img/13.png" alt="">
            </div>
            <div class="news-hanzi">
              <div class="news-title">企业校园营销如何让用户更快下单？</div>
              <div class="news-content">
                完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的培训，为企业避免因地推人员流完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的
              </div>
              <div class="news-message">
                <span class="news-liulan">浏览量：125</span>
                <span class="news-date">时间：2019-2-26</span>
              </div>
            </div>
        </div>
      </div>
    </section>
  </div>
</template>
<script>
  export default {
    name: 'newscenter',
    data() {
      return {

      }
    },
    methods: {
        godetails(){
            this.$router.push({path:'/NewsDetails'})
        }
    },
  }

</script>
<style>
    .news-module{
        cursor: pointer;
    }
</style>
