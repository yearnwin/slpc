<template>
  <div class="solution">
    <section>
      <img src="../../static/img/10.png" class="page-img" alt="">
      <div class="page-solu-top">
        <ul class="page-solu-nav">
          <li>人力资源外包</li>
          <li>业务外包</li>
          <li>猎头人才</li>
          <li>企业管理</li>
          <li>社保及公积金</li>
          <li>财务外包</li>
          <li>保安保洁外包</li>
          <li>居住证及落户</li>
          <li>外包案例</li>
          <li>HRD商学院</li>
        </ul>
      </div>
      <div class="page-solution">
        <!-- <div class="page-solu-con">
          <ul>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>
              <div class="page-solu-tit">企业管理</div>
              <div class="page-solu-msg">
                服务电话:
                <span>0000000000</span>
                QQ:
                <span>000000000</span>
                联系人:
                <span>X先生</span>
              </div>
              <div class="page-solu-text">
                <p>企业培训</p>
                <p>企业培训 企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指</p>
              </div>
              <div class="page-solu-tit mar1">服务内容</div>
              <div class="page-solu-text">
                <p>企业培训>企业培训 企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训>企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训企业培训是推动企业不断发展的重要手段之一，企业培训是推动企业不断发展的重要手段之一，
                </p>
                <p></p>
                <p>企业培训 企业培训企业培训 培训企业培训 培训企业培训 培训企业培训 企业培训企业培训 企业培训企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训</p>
                <p></p>
                <p>企业培训 企业培训企业培培训企业培训 培训企业培训 培训企业培训 训 企业培训企业培训 企业培训企业培训
                  企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训</p>
              </div>
              <img src="./img/11.png" alt="" class="text-img">
            </li>
            <li>5</li>
            <li>6</li>
            <li>7</li>
            <li>8</li>
            <li>9</li>
            <li>10</li>
          </ul>
        </div> -->
        <div class="customer">
          <div class="news-tit">
            <div class="news-tit-con">
              <span>我们的客户</span>
              <span>OUR CUSTOMERS</span>
            </div>
            <div class="news-subhead">全心全力服务好我们的每一个客户，选择惠恩，享受高品质服务。</div>
          </div>
          <div class="customer-con">
            <ul>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
              <li class="customer-mod">
                <a href="">
                  <img src="../../static/img/customer1.png" alt="" class="customer-img">
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
<script>
export default {
    name:'Solution',
    data() {
        return {
            
        }
    },
}
</script>
