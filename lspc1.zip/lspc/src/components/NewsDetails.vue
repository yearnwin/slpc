<template>
  <div class="newsdetails">
    <section>
      <img src="../../static/img/12.png" class="page-img" alt="">
      <div class="page page-newsdetails">
        <div class="page-about-title news-tit-mar">企业校园营销如何让用户更快下单？</div>
        <div class="news-message news-det">
          <span class="news-liulan">浏览量：125</span>
          <span class="news-date">时间：2019-2-26</span>
        </div>
        <div class="news-content">
          完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的培训，为企业避免因地推人员流完善传统发单式、拉访式，小规模、小范围的推广模式，采用强大的推广团队，并对每一个团队人员进行专业的培训，为企业避免因地推人员流完善传统发单式、拉访式，小规模、小范围的推广模式
        </div>
        <img class="news-det-img" src="../../static/img/17.png" alt="">
      </div>
    </section>
  </div>
</template>
<script>
export default {
    name:'NewsCenter',
    data() {
        return {
            
        }
    },
}
</script>