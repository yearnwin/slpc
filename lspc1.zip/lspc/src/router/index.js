import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

// 引入组件
import HomePage from '@/components/HomePage'
import AboutUs from '@/components/AboutUs'
import NewsCenter from '@/components/NewsCenter'
import JoinUs from '@/components/JoinUs'
import NewsDetails from '@/components/NewsDetails'
import ContactUs from '@/components/ContactUs'
import Solution from '@/components/Solution'

Vue.use(Router)

export default new Router({
  routes: [
    {
        path: '/',
        name: 'HomePage',
        component: HomePage
    },
    {
        path:'/AboutUs',
        component: AboutUs
    },
    {
        path:'/NewsCenter',
        component: NewsCenter,
    },
    {
        path:'/JoinUs',
        component: JoinUs
    },
    {
        path:'/NewsDetails',
        component: NewsDetails
    },
    {
        path:'/ContactUs',
        component: ContactUs
    },
    {
        path:'/Solution',
        component: Solution,
        children:[]
    },
  ]
})
