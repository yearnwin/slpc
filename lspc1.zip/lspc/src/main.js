// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// 引入百度地图
import BaiduMap from 'vue-baidu-map';
Vue.use(BaiduMap,{
  ak:"ZNmwGgGN5sq1Y7m8LmQPhlfNVKsK267G"
});

// 引入css
import '../static/css/swiper.css';
import '../static/css/footer.css';
import '../static/css/header.css';
import '../static/css/index.css';

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
