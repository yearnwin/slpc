<template>
  <div class="page-index">
    <section>
      <div class="swiper-container" id="swiper1">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><img src="../../static/img/banner1.png" alt="" class="banner-img"></div>
          <div class="swiper-slide"><img src="../../static/img/banner2.png" alt="" class="banner-img"></div>
          <div class="swiper-slide"><img src="../../static/img/banner1.png" alt="" class="banner-img"></div>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>

        <!-- 如果需要导航按钮 -->
        <!-- <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div> -->

        <!-- 如果需要滚动条 -->
        <!-- <div class="swiper-scrollbar"></div> -->
      </div>
    </section>
    <section>
      <div class="about-us">
        <div class="about-left">
          <img src="../../static/img/4.png" alt="">
        </div>
        <div class="about-right">
          <div class="about-right-tit"><span>关于我们</span>/ABOUT US</div>
          <div class="about-right-con">
            <p>上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局 批准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局
              批准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投上海隆晟劳务派遣有限公司是经上海市工商局和上海市人力资源和社会保障局 批准的专业机构。上海隆晟劳务派遣有限公司录属于上海财尊投</p>
          </div>
          <div class="about-right-more">
            <a href="">查看更多</a>
          </div>
        </div>
      </div>
    </section>
    <section class="weserver-bg">
      <div class="weserver">
        <div class="weserver-tit">
          <span>我们的服务领域</span>
          <span>为企业量身定制"多元化"，综合性解决方案，提供全方位或个性化服务</span>
        </div>
        <div class="myswiper">
          <div class="swiper-container" id="swiper2">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <ul class="server-ul">
                  <li class="server-item">
                    <img src="../../static/img/5.png" alt="" class="server-item-img">
                    <div class="server-item-tit">人力资源外包</div>
                    <div class="server-item-con">人力资源外包,简称HRO。指企业根据需要将某一项或几项人力资源管理工作或职能交
                      由其他企业或组织进行管理，以降低人力成本，实现人力资源外包</div>
                  </li>
                  <li class="server-item">
                    <img src="../../static/img/5.png" alt="" class="server-item-img">
                    <div class="server-item-tit">人力资源外包</div>
                    <div class="server-item-con">人力资源外包,简称HRO。指企业根据需要将某一项或几项人力资源管理工作或职能交
                      由其他企业或组织进行管理，以降低人力成本，实现人力资源外包</div>
                  </li>
                  <li class="server-item">
                    <img src="../../static/img/5.png" alt="" class="server-item-img">
                    <div class="server-item-tit">人力资源外包</div>
                    <div class="server-item-con">人力资源外包,简称HRO。指企业根据需要将某一项或几项人力资源管理工作或职能交
                      由其他企业或组织进行管理，以降低人力成本，实现人力资源外包</div>
                  </li>
                  <li class="server-item">
                    <img src="../../static/img/5.png" alt="" class="server-item-img">
                    <div class="server-item-tit">人力资源外包</div>
                    <div class="server-item-con">人力资源外包,简称HRO。指企业根据需要将某一项或几项人力资源管理工作或职能交
                      由其他企业或组织进行管理，以降低人力成本，实现人力资源外包</div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="swiper-button-prev"></div>
          <div class="swiper-button-next"></div>
        </div>
        <div class="server-more">
          <a href="">查看更多</a>
        </div>
      </div>
    </section>
    <section>
      <div class="news-cneter">
        <div class="news-tit">
          <div class="news-tit-con">
            <span>新闻中心</span>
            <span>NEWS CENTER</span>
          </div>
          <div class="news-subhead">分享创造价值，记录企业发展脚步</div>
        </div>
        <div class="news-con">
          <ul>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
            <li class="news-mod">
              <a href="">
                <img src="../../static/img/news1.png" alt="" class="news-img">
                <div class="news-name">赴滇“股权激励专项落地咨询指导”</div>
                <div class="news-time">2019-03-24</div>
                <div class="news-msg">1月24日至29日，隆晟集团董事长及旗 下股权落地执行团队受邀赴滇，对云南 房客通房地产</div>
              </a>
            </li>
          </ul>
        </div>
        <div class='news-more'>
          <a href="">查看更多</a>
        </div>
      </div>
    </section>
    <section class="case-bg">
      <div class="case">
        <div class="news-tit">
          <div class="news-tit-con">
            <span>外包案例</span>
            <span>OUTSOURCING CASE</span>
          </div>
          <div class="news-subhead" style="color:#fff;">用户的利益高于一切，携手隆晟、共创辉煌</div>
        </div>
        <div class="case-con">
          <ul>
            <li class="case-mod">
              <a href="">
                <img src="../../static/img/case1.png" alt="" class="case-img">
                <div class="case-name">三一集团</div>
                <div class="case-msg">2009年三一重机上海临港公司，因业务扩展，加快订单量，将其中一个生产线外包给我司来操作。</div>
              </a>
            </li>
            <li class="case-mod">
              <a href="">
                <img src="../../static/img/case1.png" alt="" class="case-img">
                <div class="case-name">三一集团</div>
                <div class="case-msg">2009年三一重机上海临港公司，因业务扩展，加快订单量，将其中一个生产线外包给我司来操作。</div>
              </a>
            </li>
            <li class="case-mod">
              <a href="">
                <img src="../../static/img/case1.png" alt="" class="case-img">
                <div class="case-name">三一集团</div>
                <div class="case-msg">2009年三一重机上海临港公司，因业务扩展，加快订单量，将其中一个生产线外包给我司来操作。</div>
              </a>
            </li>
            <li class="case-mod">
              <a href="">
                <img src="../../static/img/case1.png" alt="" class="case-img">
                <div class="case-name">三一集团</div>
                <div class="case-msg">2009年三一重机上海临港公司，因业务扩展，加快订单量，将其中一个生产线外包给我司来操作。</div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>
    <section>
      <div class="customer">
        <div class="news-tit">
          <div class="news-tit-con">
            <span>我们的客户</span>
            <span>OUR CUSTOMERS</span>
          </div>
          <div class="news-subhead">全心全力服务好我们的每一个客户，选择惠恩，享受高品质服务。</div>
        </div>
        <div class="customer-con">
          <ul>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
            <li class="customer-mod">
              <a href="">
                <img src="../../static/img/customer1.png" alt="" class="customer-img">
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
  import Swiper from 'swiper';
  export default {
    name: 'HomePage',
    data() {
      return {
        msg: 'Welcome to Your Vue.js App'
      }
    },
    methods: {

    },
    mounted: function () {
      
      //console.log('mounted');
      var mySwiper = new Swiper('#swiper1', {
        direction: 'horizontal', // 垂直切换选项
        loop: true, // 循环模式选项
        // 如果需要分页器
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        autoplay: {
          delay: 3000,
          stopOnLastSlide: false,
          disableOnInteraction: true,
        },
      })
      var mySwiper2 = new Swiper('#swiper2', {
        direction: 'horizontal', // 垂直切换选项
        loop: true, // 循环模式选项
        autoplay: {
          delay: 3000,
          stopOnLastSlide: false,
          disableOnInteraction: true,
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      })
      // 关于我们文本溢出隐藏
      if (document.querySelector('.about-right-con>p').offsetHeight > document.querySelector('.about-right-con')
        .offsetHeight) {
        document.querySelector('.about-right-con').className += ' mytextover'
      }
    },
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
