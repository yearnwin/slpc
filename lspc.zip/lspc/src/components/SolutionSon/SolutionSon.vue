<template>
  <div class="solutionson">
    <div class="page-solu-tit">企业管理{{listid}}-{{id}}</div>
    <div class="page-solu-msg">
      服务电话:
      <span>0000000000</span>
      QQ:
      <span>000000000</span>
      联系人:
      <span>X先生</span>
    </div>
    <div class="page-solu-text">
      <p>企业培训</p>
      <p>企业培训 企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指</p>
    </div>
    <div class="page-solu-tit mar1">服务内容</div>
    <div class="page-solu-text">
      <p>企业培训>企业培训 企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训>企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训企业培训是推动企业不断发展的重要手段之一，企业培训是推动企业不断发展的重要手段之一，
      </p>
      <p></p>
      <p>企业培训 企业培训企业培训 培训企业培训 培训企业培训 培训企业培训 企业培训企业培训 企业培训企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训</p>
      <p></p>
      <p>企业培训 企业培训企业培培训企业培训 培训企业培训 培训企业培训 训 企业培训企业培训 企业培训企业培训
        企业培训是推动企业不断发展的重要手段之一，企业培训市场上常见的培训形式包括企业内训、各类EMBA研修等。企业培训是指企业培训</p>
    </div>
    <img src="../../../static/img/11.png" alt="" class="text-img">
  </div>
</template>
<script>
export default {
    name:'SolutionSon',
    props:{listid:Number},
    data() {
        return {
            id:this.listid
        }
    },
    beforeUpdate() {
        this.id=this.listid
    },
    mounted() {
        
    },
    methods: {
        
    },
}
</script>