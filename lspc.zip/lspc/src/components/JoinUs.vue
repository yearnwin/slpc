<template>
    <div class="joinus">
        <section>
        <img src="../../static/img/16.png" class="page-img" alt="">
        <div class="page">
            <div class="page-solu-tit">加入隆晟</div>
            <div class="page-joinus">
                <p>一、投资经理（1人）</p>
                <p> 工作地点：上海嘉定区 </p>
                <p>薪酬福利：20k~50k+绩效分红 </p>
                <p>岗位职责：</p>
                <p> 1、掌握行业基本面及最新动态，深度</p>
                <p> 1、掌握行业基本面及最新动态，深度</p>
                <p> 1、掌握行业基本面及最新动态，深度</p>
            </div>
        </div>
    </section>
    </div>
</template>
<script>
export default {
    name:'JoinUs',
    data() {
        return {
            
        }
    },
}
</script>