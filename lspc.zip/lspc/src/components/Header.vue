<template>
  <div class="header">
    <header>
      <div class="top-msg-area">
        <div class="top-msg">
          <img :src="myurl+img.logo" alt="" class="top-logo">
          <ul class="top-msg-list">
            <li>
              <img :src="myurl+img.phone" alt="">
              <div class="msg-con">
                <span>服务热线电话</span>
                <span>12345678910</span>
              </div>
            </li>
            <li>
              <img :src="myurl+img.site" alt="">
              <div class="msg-con">
                <span>我们的地址</span>
                <span>于上海大虹桥板块商务园区漓江桥万达广场</span>
              </div>
            </li>
            <li>
              <img :src="myurl+img.time" alt="">
              <div class="msg-con">
                <span>我们的服务时间</span>
                <span>周一至周日 09:00-22:00</span>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="top-nav">
        <ul>
            <li>
                <router-link to="/">首页</router-link>
                <!-- <a href="index.html">首页</a> -->
            </li>
            <li>
                <router-link to="/AboutUs">关于我们</router-link>
                <!-- <a href="aboutus.html">关于我们</a> -->
                </li>
            <li>
                <router-link to="/Solution">解决方案</router-link>
                <!-- <a href="solution.html">解决方案</a> -->
            </li>
            <li>
                <router-link to="/NewsCenter">新闻中心</router-link>
                <!-- <a href="newscenter.html">新闻中心</a> -->
            </li>
            <li>
                <router-link to="/NewsCenter">慈善公益</router-link>
                <!-- <a href="charity.html">慈善公益</a> -->
            </li>
            <li>
                <router-link to="/ContactUs">联系我们</router-link>
                <!-- <a href="contactus.html">联系我们</a> -->
            </li>
            <li>
                <router-link to="/JoinUs">加入隆晟</router-link>
                <!-- <a href="joinus.html">加入隆晟</a> -->
            </li>
        </ul>
      </div>
    </header>
  </div>
</template>
<script>
  export default {
    name: 'myheader',
    data() {
      return {
        img: {
          logo:'/public/pc/img/logo.png',
          phone:'/public/pc/img/1.png',
          site:'/public/pc/img/2.png',
          time:'/public/pc/img/3.png'
        },
      }
    },
  }
</script>
<style>

</style>
