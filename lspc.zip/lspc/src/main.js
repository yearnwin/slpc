// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

import axios from 'axios'
// 引入css
import '../static/css/swiper.css';
import '../static/css/footer.css';
import '../static/css/header.css';
import '../static/css/index.css';

// 全局变量
Vue.prototype.myurl='http://shls.hfcn.cc'

Vue.prototype.$axios=axios
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
