<template>
  <div id="app">
    <myheader></myheader>
    <router-view />
    <myfooter></myfooter>
  </div>
</template>

<script>
    import myheader from './components/Header'
    import myfooter from './components/Footer'
    export default {
        name: 'App',
        components:{
            myheader,
            myfooter
        }
    }

</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    /* text-align: center; */
    color: #2c3e50;
    /* margin-top: 60px; */
  }

</style>
